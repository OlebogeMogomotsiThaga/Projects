﻿CREATE TABLE USERS (
	id INT NOT NULL PRIMARY KEY IDENTITY,
	usertype int NOT NULL,
	name VARCHAR (100) NOT NULL,
	surname VARCHAR (100) NOT NULL,
	email VARCHAR (100) NOT NULL UNIQUE,
	phone VARCHAR (10) NOT NULL,
	created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO USERS(usertype,name, surname, email, phone)
VALUES
(1,'Aziz', 'Hass','ah@gmail.com', 0778529636),
(1,'lora', 'Jola','lj@gamil.com', 0845559632),
(2,'sipho', 'Stevo','ss@gmail.com', 0745563341),
(2,'Lebo', 'Mazo', 'lm@gmail.com',0634489941)