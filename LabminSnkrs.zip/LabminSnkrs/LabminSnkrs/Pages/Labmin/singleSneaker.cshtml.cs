using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LabminSnkrs.Pages.Labmin
{
    public class singleSneakerModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
