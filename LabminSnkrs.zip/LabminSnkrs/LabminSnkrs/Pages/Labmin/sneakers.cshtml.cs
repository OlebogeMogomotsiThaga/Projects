using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace LabminSnkrs.Pages.Labmin
{
    public class sneakersModel : PageModel
    {
        public void OnGet()
        {

        }
    }

    public class sneaker {
        public int sneaker_Id;
        public String name;
        public String colour;
        public String Fprice;
        public String Description;
        public String sizerun;
        public String image;
       


    }
}
