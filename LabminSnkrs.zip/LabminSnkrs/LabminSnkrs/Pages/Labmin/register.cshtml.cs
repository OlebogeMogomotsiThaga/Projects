using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace LabminSnkrs.Pages.Labmin
{
    public class registerModel : PageModel
    {
        public UserInfo userinfo = new UserInfo();
        public String errorMesssage = "";
        public String successMessage = "";
        public void OnGet()
        {

        }

        public void OnPost() 
        {
            Int32 usertype = 2;
            userinfo.email = Request.Form["email"];
            userinfo.surname = Request.Form["surname"];
            userinfo.name = Request.Form["name"];
            userinfo.phone = Request.Form["phone"];
            userinfo.upassword = Request.Form["upassword"];
            userinfo.usertype = usertype.ToString();

            if (userinfo.email.Length == 0 || userinfo.name.Length == 0 || userinfo.surname.Length == 0 ||
                userinfo.phone.Length == 0 || userinfo.upassword.Length == 0)
            {
                errorMesssage = "All the fields are required";
                return;
            }

            var confirmPassword = Request.Form["re_password"]; 
            if (userinfo.upassword != confirmPassword) 
            {
                errorMesssage = "Passwords do not match. Please try again.";
                return; 
            }

            try 
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=LabminSnkrs;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "INSERT INTO USERS" +
                                "(usertype, name, surname, email, phone, upassword) VALUES " +
                                "(@usertype, @name, @surname,@email, @phone, @upassword);";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@name", userinfo.name);
                        command.Parameters.AddWithValue("@usertype", userinfo.usertype);
                        command.Parameters.AddWithValue("@surname", userinfo.surname);
                        command.Parameters.AddWithValue("@email", userinfo.email);
                        command.Parameters.AddWithValue("@phone", userinfo.phone);
                        command.Parameters.AddWithValue("@upassword", userinfo.upassword);

                        command.ExecuteNonQuery();
                    }
                }
            }

            catch (Exception ex)
            {
                errorMesssage = ex.Message;
                return ;
            }

            userinfo.name = ""; userinfo.surname = ""; userinfo.email = ""; userinfo.phone = "";
            successMessage = "New User added ";
            Response.Redirect("/Labmin/Index");
        }

    }
}
  