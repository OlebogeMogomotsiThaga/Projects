using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Numerics;
using System.Xml.Linq;
using System;
using System.Data.SqlClient;

namespace LabminSnkrs.Pages.Labmin
{
    public class IndexModel : PageModel
    {
        public List<UserInfo> listUsers = new List<UserInfo>();
        public void OnGet()
        {
            try 
            {
                String connectionString = "Data Source=.\\sqlexpress;Initial Catalog=LabminSnkrs;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM USERS";
                    using (SqlCommand command = new SqlCommand(sql, connection)) 
                    {
                        using (SqlDataReader reader = command.ExecuteReader()) 
                        {
                            while (reader.Read())
                            {
                                UserInfo userInfo = new UserInfo();
                                userInfo.id = "" + reader.GetInt32(0);
                                userInfo.usertype = "" + reader.GetInt32(1);
                                userInfo.name = reader.GetString(2);
                                userInfo.surname = reader.GetString(3);
                                userInfo.email = reader.GetString(4);
                                userInfo.phone = reader.GetString(5);
                                userInfo.upassword = reader.GetString(6);
                                userInfo.created_at = reader.GetDateTime(7).ToString();

                                listUsers.Add(userInfo);
                                Console.WriteLine(userInfo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex) 
            {
                Console.WriteLine("Exception is: "+ ex.ToString());   
            }

        }
    }

    public class UserInfo
    {
        public String id;
        public String usertype;
        public String name;
        public String surname;
        public String email;
        public String phone;
        public String upassword;
        public String created_at;
    }
}
