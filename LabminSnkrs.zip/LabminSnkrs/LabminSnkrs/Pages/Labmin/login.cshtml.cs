using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;

namespace LabminSnkrs.Pages.Labmin
{
    public class loginModel : PageModel
    {
        public UserInfo userinfo = new UserInfo();
        public String errorMessage = "";
        public String successMessage = "";


            public void OnPost()
        {
             userinfo.email = Request.Form["email"];
             userinfo.upassword = Request.Form["password"];
            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=LabminSnkrs;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM USERS WHERE email=@"+ userinfo.email;
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@email", userinfo.email); 
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                             if (reader.Read())
                             {
                                userinfo.id = "" + reader.GetInt32(0);
                                userinfo.email = reader.GetString(1);
                                userinfo.usertype = reader.GetString(2);
                                userinfo.upassword = reader.GetString(3); 
                             }
                             command.ExecuteNonQuery();

                             

                           
                        }
                    }
                }
            } 
            catch (Exception ex)
            {
                errorMessage = ex.Message; 
            }
            Response.ContentType = "text/html";
        }
    }
}
