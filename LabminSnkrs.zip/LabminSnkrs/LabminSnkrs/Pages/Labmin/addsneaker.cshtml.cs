using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LabminSnkrs.Pages.Labmin
{
    public class addsneakerModel : PageModel
    {
        public List<SneakerInventory> listSneakers = new List<SneakerInventory>();

        public SneakerInventory sneakers = new SneakerInventory(); 



        public void OnGet()
        {

        }

        public void OnPost()
        {
            sneakers.name = Request.Form["sneakername"];
            sneakers.colour = Request.Form["colourdescription"];
            sneakers.Fprice = Request.Form["sneakerprice"]; 
            sneakers.Description = Request.Form["Description"];
            sneakers.sizerun = Request.Form["sizerun"];
            sneakers.image = Request.Form["sneakerimage"]; 
        }
    }

    public class SneakerInventory
    {
        public int sneaker_Id;
        public String name;
        public String colour;
        public String Fprice;
        public String Description;
        public String sizerun;
        public String image;
    }
}
